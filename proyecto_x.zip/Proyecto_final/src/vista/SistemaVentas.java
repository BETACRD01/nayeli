package vista;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

// Clase principal
public class SistemaVentas {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::crearLogin);
    }
}

// Clase para la conexión a la base de datos
class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_ventas_2";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}

// Ventana de Login
class Login {
    public static void crearLogin() {
        JFrame frame = new JFrame("Login");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        frame.add(panel);

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioLabel.setBounds(10, 20, 80, 25);
        panel.add(usuarioLabel);

        JTextField usuarioText = new JTextField(20);
        usuarioText.setBounds(100, 20, 165, 25);
        panel.add(usuarioText);

        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 50, 165, 25);
        panel.add(passwordText);

        JButton loginButton = new JButton("Ingresar");
        loginButton.setBounds(100, 90, 100, 25);
        panel.add(loginButton);

        loginButton.addActionListener(e -> {
            String usuario = usuarioText.getText();
            String password = new String(passwordText.getPassword());
            if (validarUsuario(usuario, password)) {
                JOptionPane.showMessageDialog(frame, "Login exitoso");
                frame.dispose();
                Vista.mostrarVentana();
            } else {
                JOptionPane.showMessageDialog(frame, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        frame.setVisible(true);
    }

    private static boolean validarUsuario(String usuario, String password) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND password = ? AND estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

// Ventana principal con pestañas
class Vista {
    public static void mostrarVentana() {
        JFrame frame = new JFrame("Sistema de Ventas");
        frame.setSize(1000, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        // Creamos el tabbedPane con las 3 pestañas
        JTabbedPane tabbedPane = new JTabbedPane();
        PanelClientes panelClientes = new PanelClientes();
        PanelProductos panelProductos = new PanelProductos();
        PanelVentas panelVentas = new PanelVentas();

        tabbedPane.addTab("Clientes", panelClientes);
        tabbedPane.addTab("Productos", panelProductos);
        tabbedPane.addTab("Ventas", panelVentas);

        // Agregamos un ChangeListener para que, cada vez que entres a la pestaña "Ventas",
        // recargue los combos y la tabla de ventas con la info actualizada.
        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int index = tabbedPane.getSelectedIndex();
                // Si la pestaña seleccionada es la de "Ventas" (índice 2):
                if (index == 2) {
                    panelVentas.cargarClientesCombo();
                    panelVentas.cargarProductosCombo();
                    panelVentas.cargarVentas();
                }
            }
        });

        frame.add(tabbedPane);
        frame.setVisible(true);
    }
}

// Panel para gestionar Clientes
class PanelClientes extends JPanel {
    private JTable tablaClientes;
    private DefaultTableModel modelo;
    private JTextField txtDni, txtNombre, txtTelefono, txtDireccion;

    public PanelClientes() {
        setLayout(new BorderLayout());

        // Formulario de datos del cliente
        JPanel formPanel = new JPanel(new GridLayout(2, 5, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Datos del Cliente"));
        formPanel.add(new JLabel("DNI:"));
        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(new JLabel("Teléfono:"));
        formPanel.add(new JLabel("Dirección:"));
        formPanel.add(new JLabel("")); // Espacio vacío

        txtDni = new JTextField();
        txtNombre = new JTextField();
        txtTelefono = new JTextField();
        txtDireccion = new JTextField();

        formPanel.add(txtDni);
        formPanel.add(txtNombre);
        formPanel.add(txtTelefono);
        formPanel.add(txtDireccion);

        JButton btnAgregar = new JButton("Agregar");
        formPanel.add(btnAgregar);
        add(formPanel, BorderLayout.NORTH);

        // Tabla para mostrar clientes
        modelo = new DefaultTableModel();
        modelo.setColumnIdentifiers(new String[]{"ID", "DNI", "Nombre", "Teléfono", "Dirección", "Fecha Registro"});
        tablaClientes = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        add(scrollPane, BorderLayout.CENTER);

        // Botones de acción
        JPanel actionPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        actionPanel.add(btnModificar);
        actionPanel.add(btnEliminar);
        add(actionPanel, BorderLayout.SOUTH);

        cargarClientes();

        btnAgregar.addActionListener(e -> agregarCliente());
        btnModificar.addActionListener(e -> modificarCliente());
        btnEliminar.addActionListener(e -> eliminarCliente());

        // Al seleccionar un registro se carga en el formulario
        tablaClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaClientes.getSelectedRow() != -1) {
                int row = tablaClientes.getSelectedRow();
                txtDni.setText(modelo.getValueAt(row, 1).toString());
                txtNombre.setText(modelo.getValueAt(row, 2).toString());
                txtTelefono.setText(modelo.getValueAt(row, 3).toString());
                txtDireccion.setText(modelo.getValueAt(row, 4).toString());
            }
        });
    }

    private void cargarClientes() {
        modelo.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, dni, nombre, telefono, direccion, fecha_registro FROM clientes WHERE estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("dni"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getTimestamp("fecha_registro")
                });
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    private void agregarCliente() {
        String dni = txtDni.getText().trim();
        String nombre = txtNombre.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String direccion = txtDireccion.getText().trim();

        // Validación: DNI debe tener 10 dígitos numéricos
        if (!dni.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "El DNI debe contener exactamente 10 dígitos numéricos.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO clientes (dni, nombre, telefono, direccion) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dni);
            stmt.setString(2, nombre);
            stmt.setString(3, telefono);
            stmt.setString(4, direccion);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Cliente agregado exitosamente.");
                cargarClientes();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al agregar cliente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificarCliente() {
        int fila = tablaClientes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente para modificar.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
        String dni = txtDni.getText().trim();
        String nombre = txtNombre.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String direccion = txtDireccion.getText().trim();

        if (!dni.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "El DNI debe contener exactamente 10 dígitos numéricos.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE clientes SET dni = ?, nombre = ?, telefono = ?, direccion = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dni);
            stmt.setString(2, nombre);
            stmt.setString(3, telefono);
            stmt.setString(4, direccion);
            stmt.setInt(5, id);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Cliente modificado exitosamente.");
                cargarClientes();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al modificar cliente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarCliente() {
        int fila = tablaClientes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un cliente para eliminar.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM clientes WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado exitosamente.");
                cargarClientes();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar cliente: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

// Panel para gestionar Productos
class PanelProductos extends JPanel {
    private JTable tablaProductos;
    private DefaultTableModel modelo;
    private JTextField txtNombre, txtPrecio, txtStock;
    private JComboBox<Item> comboCategorias;

    public PanelProductos() {
        setLayout(new BorderLayout());

        // Formulario de datos del producto
        JPanel formPanel = new JPanel(new GridLayout(2, 5, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Datos del Producto"));
        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(new JLabel("Categoría:"));
        formPanel.add(new JLabel("Precio:"));
        formPanel.add(new JLabel("Stock:"));
        formPanel.add(new JLabel("")); // Espacio vacío

        txtNombre = new JTextField();
        comboCategorias = new JComboBox<>();
        txtPrecio = new JTextField();
        txtStock = new JTextField();

        formPanel.add(txtNombre);
        formPanel.add(comboCategorias);
        formPanel.add(txtPrecio);
        formPanel.add(txtStock);

        JButton btnAgregar = new JButton("Agregar");
        formPanel.add(btnAgregar);
        add(formPanel, BorderLayout.NORTH);

        // Tabla para mostrar productos
        modelo = new DefaultTableModel();
        // Columnas: incluye una oculta para el id_categoria
        modelo.setColumnIdentifiers(new String[]{
                "ID", "Nombre", "id_categoria", "Categoría", "Precio", "Stock", "Fecha Registro"
        });
        tablaProductos = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tablaProductos);
        add(scrollPane, BorderLayout.CENTER);

        // Ocultar la columna de "id_categoria" para que el usuario no la vea
        // La columna 2 es la de "id_categoria" (contando desde 0)
        // Para ocultarla, debemos hacerlo después de añadir la tabla al scroll
        tablaProductos.getColumnModel().getColumn(2).setMinWidth(0);
        tablaProductos.getColumnModel().getColumn(2).setMaxWidth(0);
        tablaProductos.getColumnModel().getColumn(2).setWidth(0);

        // Botones de acción
        JPanel actionPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        actionPanel.add(btnModificar);
        actionPanel.add(btnEliminar);
        add(actionPanel, BorderLayout.SOUTH);

        cargarCategorias();
        cargarProductos();

        btnAgregar.addActionListener(e -> agregarProducto());
        btnModificar.addActionListener(e -> modificarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());

        // Al seleccionar un registro se carga en el formulario
        tablaProductos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaProductos.getSelectedRow() != -1) {
                int row = tablaProductos.getSelectedRow();
                txtNombre.setText(modelo.getValueAt(row, 1).toString());
                int idCategoria = Integer.parseInt(modelo.getValueAt(row, 2).toString());
                // Seleccionar en combo la categoría que coincida con idCategoria
                for (int i = 0; i < comboCategorias.getItemCount(); i++) {
                    if (comboCategorias.getItemAt(i).getId() == idCategoria) {
                        comboCategorias.setSelectedIndex(i);
                        break;
                    }
                }
                txtPrecio.setText(modelo.getValueAt(row, 4).toString());
                txtStock.setText(modelo.getValueAt(row, 5).toString());
            }
        });
    }

    private void cargarCategorias() {
        comboCategorias.removeAllItems();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, nombre FROM categorias WHERE estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                comboCategorias.addItem(new Item(id, nombre));
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarProductos() {
        modelo.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            // Hacemos JOIN con categorias para obtener el nombre de la categoría
            String sql = "SELECT p.id, p.nombre, p.id_categoria, c.nombre as categoria, p.precio, p.stock, p.fecha_registro "
                       + "FROM productos p "
                       + "JOIN categorias c ON p.id_categoria = c.id "
                       + "WHERE p.estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getInt("id_categoria"), // Columna oculta
                    rs.getString("categoria"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getTimestamp("fecha_registro")
                });
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    private void agregarProducto() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre del producto es obligatorio.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Item categoriaItem = (Item) comboCategorias.getSelectedItem();
        if (categoriaItem == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una categoría.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double precio;
        int stock;
        try {
            precio = Double.parseDouble(txtPrecio.getText().trim());
            stock = Integer.parseInt(txtStock.getText().trim());
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y Stock deben ser numéricos.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO productos (nombre, id_categoria, precio, stock) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setInt(2, categoriaItem.getId());
            stmt.setDouble(3, precio);
            stmt.setInt(4, stock);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Producto agregado exitosamente.");
                cargarProductos();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al agregar producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificarProducto() {
        int fila = tablaProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para modificar.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre del producto es obligatorio.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Item categoriaItem = (Item) comboCategorias.getSelectedItem();
        if (categoriaItem == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una categoría.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double precio;
        int stock;
        try {
            precio = Double.parseDouble(txtPrecio.getText().trim());
            stock = Integer.parseInt(txtStock.getText().trim());
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y Stock deben ser numéricos.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE productos SET nombre = ?, id_categoria = ?, precio = ?, stock = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombre);
            stmt.setInt(2, categoriaItem.getId());
            stmt.setDouble(3, precio);
            stmt.setInt(4, stock);
            stmt.setInt(5, id);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Producto modificado exitosamente.");
                cargarProductos();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al modificar producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarProducto() {
        int fila = tablaProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar.");
            return;
        }
        int id = Integer.parseInt(modelo.getValueAt(fila, 0).toString());
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM productos WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Producto eliminado exitosamente.");
                cargarProductos();
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

// Panel para gestionar Ventas
class PanelVentas extends JPanel {
    private JTable tablaVentas;
    private DefaultTableModel modeloVentas;
    private JComboBox<Item> comboClientes;
    private JComboBox<Item> comboProductos;
    private JTextField txtCantidad;

    public PanelVentas() {
        setLayout(new BorderLayout());

        // Formulario para realizar una venta
        JPanel formPanel = new JPanel(new GridLayout(2, 4, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Realizar Venta"));

        formPanel.add(new JLabel("Cliente:"));
        formPanel.add(new JLabel("Producto:"));
        formPanel.add(new JLabel("Cantidad:"));
        formPanel.add(new JLabel(""));

        comboClientes = new JComboBox<>();
        comboProductos = new JComboBox<>();
        txtCantidad = new JTextField();
        JButton btnRealizarVenta = new JButton("Realizar Venta");

        formPanel.add(comboClientes);
        formPanel.add(comboProductos);
        formPanel.add(txtCantidad);
        formPanel.add(btnRealizarVenta);

        add(formPanel, BorderLayout.NORTH);

        // Tabla de ventas
        modeloVentas = new DefaultTableModel();
        modeloVentas.setColumnIdentifiers(new String[]{"ID", "Cliente", "Producto", "Cantidad", "Total", "Fecha"});
        tablaVentas = new JTable(modeloVentas);
        add(new JScrollPane(tablaVentas), BorderLayout.CENTER);

        // Botón "Realizar Venta"
        btnRealizarVenta.addActionListener(e -> realizarVenta());
    }

    // Carga los clientes en el combo
    public void cargarClientesCombo() {
        comboClientes.removeAllItems();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, nombre FROM clientes WHERE estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                comboClientes.addItem(new Item(id, nombre));
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    // Carga los productos en el combo
    public void cargarProductosCombo() {
        comboProductos.removeAllItems();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, nombre, precio FROM productos WHERE estado = 1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                double precio = rs.getDouble("precio");
                comboProductos.addItem(new Item(id, nombre, precio));
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    // Carga las ventas en la tabla
    public void cargarVentas() {
        modeloVentas.setRowCount(0);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT v.id, c.nombre as cliente, p.nombre as producto, v.cantidad, v.total, v.fecha "
                       + "FROM ventas v "
                       + "JOIN clientes c ON v.id_cliente = c.id "
                       + "JOIN productos p ON v.id_producto = p.id";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                modeloVentas.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("cliente"),
                    rs.getString("producto"),
                    rs.getInt("cantidad"),
                    rs.getDouble("total"),
                    rs.getTimestamp("fecha")
                });
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }

    // Ejecuta la venta
    private void realizarVenta() {
        Item clienteItem = (Item) comboClientes.getSelectedItem();
        Item productoItem = (Item) comboProductos.getSelectedItem();
        if (clienteItem == null || productoItem == null) {
            JOptionPane.showMessageDialog(this, "Seleccione cliente y producto.");
            return;
        }
        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
            return;
        }
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor a 0.");
            return;
        }

        // Calcular total
        double precio = productoItem.getPrecio();
        double total = precio * cantidad;

        try (Connection conn = DBConnection.getConnection()) {
            // Preparar la inserción con retorno de ID autogenerado
            String sql = "INSERT INTO ventas (id_cliente, id_producto, cantidad, total) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, clienteItem.getId());
            stmt.setInt(2, productoItem.getId());
            stmt.setInt(3, cantidad);
            stmt.setDouble(4, total);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                // Obtener el ID de la venta recién generada
                ResultSet keys = stmt.getGeneratedKeys();
                if (keys.next()) {
                    int saleId = keys.getInt(1);
                    // Mostramos mensaje y actualizamos la tabla
                    JOptionPane.showMessageDialog(this, "Venta realizada exitosamente. Total: " + total);
                    cargarVentas();
                    // Generar factura en una nueva ventana
                    generarFactura(saleId);
                }
            }
        } catch(SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al realizar venta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Genera una ventana con la factura de la venta
    private void generarFactura(int saleId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT v.id, c.nombre as cliente, p.nombre as producto, v.cantidad, v.total, v.fecha "
                       + "FROM ventas v "
                       + "JOIN clientes c ON v.id_cliente = c.id "
                       + "JOIN productos p ON v.id_producto = p.id "
                       + "WHERE v.id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, saleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Creamos una ventana (JFrame) para mostrar la factura
                JFrame invoiceFrame = new JFrame("Factura #" + saleId);
                invoiceFrame.setSize(400, 300);
                invoiceFrame.setLocationRelativeTo(this);

                JTextArea textArea = new JTextArea();
                textArea.setEditable(false);

                StringBuilder sb = new StringBuilder();
                sb.append("FACTURA #").append(rs.getInt("id")).append("\n\n");
                sb.append("Cliente: ").append(rs.getString("cliente")).append("\n");
                sb.append("Producto: ").append(rs.getString("producto")).append("\n");
                sb.append("Cantidad: ").append(rs.getInt("cantidad")).append("\n");
                sb.append("Total: ").append(rs.getDouble("total")).append("\n");
                sb.append("Fecha: ").append(rs.getTimestamp("fecha")).append("\n");

                textArea.setText(sb.toString());
                invoiceFrame.add(new JScrollPane(textArea));
                invoiceFrame.setVisible(true);
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
}

// Clase auxiliar para representar ítems en ComboBox (Clientes, Categorías y Productos)
class Item {
    private int id;
    private String nombre;
    private double precio; // Opcional para productos

    public Item(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.precio = 0.0;
    }

    public Item(int id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
